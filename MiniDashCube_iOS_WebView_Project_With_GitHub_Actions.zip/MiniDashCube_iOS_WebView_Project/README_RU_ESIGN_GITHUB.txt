Как сделать IPA для ESign без Mac через GitHub Actions

1. Создай аккаунт GitHub.
2. Создай новый репозиторий.
3. Загрузи в репозиторий ВСЁ содержимое этой папки:
   - MiniDashCubeApp
   - MiniDashCubeApp.xcodeproj
   - .github
   - README-файлы

4. Открой вкладку Actions.
5. Выбери Build unsigned IPA.
6. Нажми Run workflow.
7. Дождись зелёной галочки.
8. Открой готовый запуск workflow.
9. Внизу в Artifacts скачай MiniDashCubeApp-unsigned-ipa.
10. Внутри будет MiniDashCubeApp-unsigned.ipa.
11. Импортируй этот IPA в ESign.
12. В ESign подпиши его своим сертификатом .p12 + .mobileprovision.
13. После подписи нажми Install.

Важно:
- Это неподписанный IPA. Его нельзя просто установить напрямую.
- Для ESign всё равно нужен рабочий сертификат и mobileprovision.
- Если сертификат отзовут, приложение может перестать открываться.
